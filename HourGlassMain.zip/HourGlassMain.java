
public class HourGlassMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Hourglass hourglass = new Hourglass();
		
		hourglass.makeTopOfHourGlass();
		hourglass.makeTopBodyOfHourGlass();
		hourglass.makeBottomBodyOfHourGlass();

	}

}
