import java.util.Scanner;

public class Hourglass {

	private int size;
	private int percentSand;
	private char backSlash = '\\';
	private char forwardSlash = '/';
	
	public Hourglass() {
		
	}

	protected void makeTopOfHourGlass() {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter size:");
		size = keyboard.nextInt();
		/**System.out.println("How much sand?");
		percentSand = Math.round(keyboard.nextInt()); **/
		String repeatedLines = new String(new char[(size * 2) + 2]).replace("\0", "_");
		System.out.println(repeatedLines);
	}
	
	protected void makeTopBodyOfHourGlass() {
		int tierDownBackSlash = 1;
		int tierDownForwardSlash = size * 2;
		for(int i=0; i < size; i++) {
			String sizeFormat = "%" + tierDownBackSlash + "s " + "%" + tierDownForwardSlash + "s\n";
			System.out.printf(sizeFormat, backSlash, forwardSlash);
			tierDownBackSlash += 1;
			tierDownForwardSlash -= 2;
		}
	}
	
	protected void makeBottomBodyOfHourGlass() {
		int tierUpForwardSlash = size;
		int tierUpBackSlash = 2;
		String repeatedLines = new String(new char[(size * 2)]).replace("\0", "_");
		for(int i =0; i < size - 1; i++) {
			String sizeFormat = "%" + tierUpForwardSlash + "s " + "%" + tierUpBackSlash + "s\n";
			System.out.printf(sizeFormat, forwardSlash, backSlash);
			tierUpBackSlash += 2;
			tierUpForwardSlash -= 1;
		}
		System.out.println("/" + repeatedLines + "\\");
	}
}
