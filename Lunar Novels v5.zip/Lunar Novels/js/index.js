/**
 * Created by Cedrik on 8/15/2016.
 */
$(document).ready(function() {
    $(".bookNext").button();
});