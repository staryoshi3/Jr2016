/**
 * Created by Cedrik on 8/15/2016.
 */
$(document).ready(function () {
    var InfiniteRotator = {
        init: function () {
            //initial fade-in time (in milliseconds)
            var initialFadeIn = 4000;
            //interval between items (in milliseconds)
            var itemInterval = 4000;
            //cross-fade time (in milliseconds)
            var fadeTime = 4000;
            //count number of items
            var rotationLimit = $('td').length + 1;
            //set current item
            var currentItem = 0;
            //loop through the items
            var infiniteLoop = setInterval(function () {
                $('td').eq(currentItem).find('.fade-group').fadeToggle(fadeTime);
                currentItem++;
                if (currentItem == rotationLimit) currentItem = 0;
            }, itemInterval);
        }
    };
    InfiniteRotator.init();
});